<?php include_once("header.php"); ?>
        
    <main>
        
        <div class="produtos_container">
            <div class="card_produtos">
                <ul>
                    <?php listarLivrosProdutos(); ?>
                </ul>
            </div>
     
        
        </div>

    </main>        
        
<?php include_once("footer.php"); ?>