<?php include_once("header.php"); ?>
        
    <main>
        >> CONTEÚDO AQUI <<

        <ul style="list-style: none; color: red; font-weight: bold; text-align: left; padding-top: 20px; width: 60%; margin: 0 auto;">
            <li>1) Crie uma cópia dessa página</li>
            <li>2) Renomeie de acordo com a página que vc for fazer (Exemplo: de index.php para pagina.php)</li>
            <li>3) Agora é só colocar todo o conteúdo dentro da tag < main ></li>
            <li>4) Se quiser criar um arquivo css só para sua página, crie o arquivo na pasta css e não se esqueça de adicionar o arquivo no header.php</li>
            <li>5) Coloquei um form de exemplo no arquivo form_exemplo.php, mas ele usa bootstrap. O link do bootstrap nesse exemplo tá dentro do main pq é só pra teste mesmo (por isso ele tá ferrando o footer e o menu dropdown). Para facilitar a criação do form poderiamos pensar em algum framework tipo bootstrap/materialize/semantic ui</li>
        </ul>
        

    </main>        
        
<?php include_once("footer.php"); ?>