<?php include_once("header.php"); ?>

<div class="container">
    <!-- <main> -->
        <div class="row">
            <div class="col">
            <br>
            <br>
                <h1>Quem somos</h1>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <section>
                        <img src="img/about.jpeg" class="img-fluid" alt="">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt architecto autem ea minus
                            quaerat
                            nostrum nisi doloremque non doloribus sequi iste illum, similique ipsa alias ipsum rem
                            perferendis
                            atque amet.
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat, repellendus
                            necessitatibus!
                            Blanditiis maxime tempore sunt natus et incidunt quae, quas aperiam ab facilis. Excepturi
                            recusandae, in dolor voluptatibus quis consequuntur.
                        </p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt architecto autem ea minus
                            quaerat
                            nostrum nisi doloremque non doloribus sequi iste illum, similique ipsa alias ipsum rem
                            perferendis
                            atque amet.
                            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae neque odio maxime
                            voluptas
                            ullam ipsam dolores quis cumque voluptatum, quas alias perspiciatis commodi aut omnis autem,
                            molestias aliquam veniam earum.
                        </p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt architecto autem ea minus
                            quaerat
                            nostrum nisi doloremque non doloribus sequi iste illum, similique ipsa alias ipsum rem
                            perferendis
                            atque amet.</p>
                    </section>
                </div>
            </div>
        </div>

    <!-- </main> -->
</div>

<?php include_once("footer.php"); ?>