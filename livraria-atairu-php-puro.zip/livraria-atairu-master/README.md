# Projeto Integrador - Grupo 04


## Livraria Ataîru - E-commerce
![Livraria Ataîru](/img/LivrariaAtaîru-logo-Courier_New.png "Livraria Ataîru")

---

* Milena Yamamoto
* Paola Brito
* Regiane Machado
* Renan Martins
* Valter Rodriguez
* Irailda Fernandes

---
